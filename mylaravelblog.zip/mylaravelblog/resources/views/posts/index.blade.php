@extends('layouts.app')

@section('title','| All Posts')

@section('content')

<div class="container">
	@if (Route::has('login'))
                        <div class="alert alert-success" role="alert">
                           <strong>Successfully logged in</strong> {{ session('status') }}
                        </div>
      @endif
	<div class="row justify-content-center">
		<div class="col-md-10">
			<h1>All Posts</h1>
		</div>

		<div class="col-md-2">
			<a href="{{ route('posts.create') }}" class="btn btn-lg btn-block btn-primary">Post New Blog</a>
		</div>
		
	</div>
	<hr>
	<br>
	<br>

	<div class="row justify-content-center">
		<div class="col-md-12">
			<table class="table">
				<thead>
					<th>#</th>
					<th>Title</th>
					<th>Content</th>
					<th>Created At</th>
					<th></th>
				</thead>
				<tbody>
					@foreach ($posts as $post)

					<tr>
						<th>{{ $post->id }}</th>
						<td>{{ $post->title }}</td>
						<td>{{ substr($post->content, 0, 50) }}{{ strlen($post->content) > 50 ? "..." : "" }}</td>
						<td>{{ date('M j, Y', strtotime($post->created_at)) }}</td>
						<td><a href="{{ route('posts.show', $post->id) }}" class="btn btn-info btn-sm">View</a></td>
					</tr>

					@endforeach

				</tbody>
				
			</table>
	</div>

</div>
</div>
@stop
