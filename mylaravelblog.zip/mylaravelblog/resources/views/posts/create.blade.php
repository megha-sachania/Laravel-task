@extends('layouts.app')

@section('title','| Create New Blog Post')

@section('content')

<div class="container">
	@if (count($errors) > 0)
     	<div class="alert alert-danger" role="alert">
     		<strong>Errors:</strong>
     		<ul>
     		  @foreach ($errors->all() as $error)
     		  <li>{{ $error }}</li>
     		  @endforeach
     		</ul>
     	</div>
     @endif
	<div class="row justify-content-center">
		<div class="col-md-8 col-md-4 col-md-offset-2">
			<h1>Create New Post</h1>
			<hr>
				{!! Form::open(array('route' => 'posts.store')) !!}
    				{{ Form::label('title', 'Title :',['style' => 'font-weight: bold;font-size: 20px;']) }}
    				{{ Form::text('title', null, array('class' => 'form-control', 'style' => 'margin-bottom: 10px;')) }}
    				{{ Form::label('content', "Post Content :",['style' => 'font-weight: bold;font-size: 20px;']) }}
    				{{ Form::textarea('content', null, array('class' => 'form-control')) }}
    				{{ Form::submit('Create Post', array('class' => 'btn btn-success btn-lg btn-block', 'style' => 'margin-top: 20px;font-weight: bold;')) }}
				{!! Form::close() !!}
		</div>

	</div>
</div>

@endsection

