<?php $__env->startSection('title','| Create New Blog Post'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
	<?php if(count($errors) > 0): ?>
     	<div class="alert alert-danger" role="alert">
     		<strong>Errors:</strong>
     		<ul>
     		  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     		  <li><?php echo e($error); ?></li>
     		  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     		</ul>
     	</div>
     <?php endif; ?>
	<div class="row justify-content-center">
		<div class="col-md-8 col-md-4 col-md-offset-2">
			<h1>Create New Post</h1>
			<hr>
				<?php echo Form::open(array('route' => 'posts.store')); ?>

    				<?php echo e(Form::label('title', 'Title :',['style' => 'font-weight: bold;font-size: 20px;'])); ?>

    				<?php echo e(Form::text('title', null, array('class' => 'form-control', 'style' => 'margin-bottom: 10px;'))); ?>

    				<?php echo e(Form::label('content', "Post Content :",['style' => 'font-weight: bold;font-size: 20px;'])); ?>

    				<?php echo e(Form::textarea('content', null, array('class' => 'form-control'))); ?>

    				<?php echo e(Form::submit('Create Post', array('class' => 'btn btn-success btn-lg btn-block', 'style' => 'margin-top: 20px;font-weight: bold;'))); ?>

				<?php echo Form::close(); ?>

		</div>

	</div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>