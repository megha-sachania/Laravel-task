<?php $__env->startSection('title','| View Post'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
	 <?php if(Session::has('success')): ?>
            <div class="alert alert-success" role="alert">
                <strong>Success:</strong><?php echo e(Session::get('success')); ?>

            </div>
     <?php endif; ?>

     
	<div class="row justify-content-center">
		<div class="col-md-8 col-md-4 col-md-offset-2">
			<h1><?php echo e($post->title); ?></h1>
			<p class="lead"><?php echo e($post->content); ?></p>
			<hr>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>